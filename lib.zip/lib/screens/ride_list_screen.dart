import 'package:flutter/material.dart';
import 'package:maintenance_app/l10n/app_localizations.dart';
import 'package:maintenance_app/models/crew_member.dart';
import 'package:maintenance_app/screens/add_ride_screen.dart';
import 'package:maintenance_app/screens/login_screen.dart';
import 'package:maintenance_app/services/auth_service.dart';
import 'package:maintenance_app/services/ride_service.dart';
import 'package:maintenance_app/models/ride.dart';
import 'package:maintenance_app/screens/ride_detail_screen.dart';
import 'package:maintenance_app/services/selected_park_controller.dart';
import 'package:maintenance_app/utils/error_messages.dart';
import 'package:maintenance_app/utils/text_direction.dart';

enum RideSortOption { name, status }

class RideListScreen extends StatefulWidget {
  final CrewMember crewMember;

  const RideListScreen({super.key, required this.crewMember});

  @override
  State<RideListScreen> createState() => _RideListScreenState();
}

class _RideListScreenState extends State<RideListScreen> {
  RideSortOption _sortOption = RideSortOption.name;
  String _searchText = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.rideList),
        actions: [
          IconButton(
            onPressed: () async {
              await AuthService().signOut();
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
                (route) => false,
              );
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
                vertical: 8.0,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      textDirection: textDirectionFor(_searchText),
                      textAlign: TextAlign.right,
                      decoration: InputDecoration(
                        labelText: AppLocalizations.of(context)!.search,
                        prefixIcon: const Icon(Icons.search),
                      ),
                      onChanged: (value) {
                        setState(() {
                          _searchText = value;
                        });
                      },
                    ),
                  ),
                  DropdownButton<RideSortOption>(
                    value: _sortOption,
                    underline: const SizedBox(),
                    items: [
                      DropdownMenuItem(
                        value: RideSortOption.name,
                        child: Text(AppLocalizations.of(context)!.sortByName),
                      ),
                      DropdownMenuItem(
                        value: RideSortOption.status,
                        child: Text(AppLocalizations.of(context)!.sortByStatus),
                      ),
                    ],
                    onChanged: (newOption) {
                      setState(() {
                        _sortOption = newOption!;
                      });
                    },
                  ),
                ],
              ),
            ),
            Expanded(
              child: StreamBuilder<List<Ride>>(
                stream: RideService().getAllRidesStream(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text(
                      '${AppLocalizations.of(context)!.error}: ${friendlyError(context, snapshot.error!)}',
                    );
                  }
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final rides = snapshot.data!;

                  final String? effectiveParkId =
                      (widget.crewMember.role == CrewRole.administrator ||
                          widget.crewMember.role == CrewRole.inspector)
                      ? SelectedParkController.parkId.value
                      : widget.crewMember.parkId;

                  if (effectiveParkId == null) {
                    return Center(
                      child: Text(AppLocalizations.of(context)!.noParkAssigned),
                    );
                  }

                  final filteredRides = rides.where((ride) {
                    final matchesSearch = ride.name.toLowerCase().contains(
                      _searchText.toLowerCase(),
                    );
                    return matchesSearch &&
                        ride.parkId == effectiveParkId &&
                        (widget.crewMember.role == CrewRole.administrator ||
                            ride.status != RideStatus.retired);
                  }).toList();

                  final activeRides = filteredRides
                      .where((ride) => ride.status != RideStatus.retired)
                      .toList();
                  final retiredRides = filteredRides
                      .where((ride) => ride.status == RideStatus.retired)
                      .toList();

                  if (_sortOption == RideSortOption.name) {
                    activeRides.sort((a, b) => a.name.compareTo(b.name));
                  } else {
                    activeRides.sort(
                      (a, b) => _statusPriority(
                        a.status,
                      ).compareTo(_statusPriority(b.status)),
                    );
                  }

                  retiredRides.sort((a, b) => a.name.compareTo(b.name));

                  if (filteredRides.isEmpty) {
                    return Center(
                      child: Text(AppLocalizations.of(context)!.noRides),
                    );
                  }
                  return ListView(
                    children: [
                      ...activeRides.map(
                        (ride) => _buildRideTile(context, ride),
                      ),

                      if (retiredRides.isNotEmpty)
                        Center(
                          child: Text(
                            AppLocalizations.of(context)!.retiredRidesSection,
                          ),
                        ),
                      ...retiredRides.map(
                        (ride) => _buildRideTile(context, ride),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: widget.crewMember.role == CrewRole.administrator
          ? FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const AddRideScreen(),
                  ),
                );
              },
              child: const Icon(Icons.add),
            )
          : null,
    );
  }

  String _statusLabel(BuildContext context, RideStatus status) {
    switch (status) {
      case RideStatus.operational:
        return AppLocalizations.of(context)!.statusOperational;
      case RideStatus.underMaintenance:
        return AppLocalizations.of(context)!.statusUnderMaintenance;
      case RideStatus.outOfService:
        return AppLocalizations.of(context)!.statusOutOfService;
      case RideStatus.retired:
        return AppLocalizations.of(context)!.statusRetired;
    }
  }

  int _statusPriority(RideStatus status) {
    switch (status) {
      case RideStatus.outOfService:
        return 0;
      case RideStatus.underMaintenance:
        return 1;
      case RideStatus.operational:
        return 2;
      case RideStatus.retired:
        return 4;
    }
  }

  Widget _buildRideTile(BuildContext context, Ride ride) {
    return ListTile(
      title: Text('${AppLocalizations.of(context)!.name}: ${ride.name}'),
      subtitle: Text(
        '${AppLocalizations.of(context)!.status}: ${_statusLabel(context, ride.status)}',
      ),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => RideDetailScreen(
              rideId: ride.id,
              crewMember: widget.crewMember,
            ),
          ),
        );
      },
    );
  }
}
