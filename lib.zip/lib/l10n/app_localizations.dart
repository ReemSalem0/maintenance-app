import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_he.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('he'),
  ];

  /// No description provided for @welcomeBack.
  ///
  /// In en, this message translates to:
  /// **'Welcome Back!'**
  String get welcomeBack;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Log in'**
  String get login;

  /// No description provided for @addCrewMember.
  ///
  /// In en, this message translates to:
  /// **'Add Crew Member'**
  String get addCrewMember;

  /// No description provided for @name.
  ///
  /// In en, this message translates to:
  /// **'Name'**
  String get name;

  /// No description provided for @selectRole.
  ///
  /// In en, this message translates to:
  /// **'Select Role'**
  String get selectRole;

  /// No description provided for @emailValidationError.
  ///
  /// In en, this message translates to:
  /// **'Please enter a valid email address'**
  String get emailValidationError;

  /// No description provided for @requiredField.
  ///
  /// In en, this message translates to:
  /// **'This is a required field'**
  String get requiredField;

  /// No description provided for @crewMemberNotFound.
  ///
  /// In en, this message translates to:
  /// **'Crew Member not found'**
  String get crewMemberNotFound;

  /// No description provided for @welcomeActive.
  ///
  /// In en, this message translates to:
  /// **'Welcome, you are now activated'**
  String get welcomeActive;

  /// No description provided for @loginSuccessful.
  ///
  /// In en, this message translates to:
  /// **'Login successful!'**
  String get loginSuccessful;

  /// No description provided for @crewMemberAddedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Crew Member added successfully!'**
  String get crewMemberAddedSuccessfully;

  /// No description provided for @roleAdministrator.
  ///
  /// In en, this message translates to:
  /// **'Administrator'**
  String get roleAdministrator;

  /// No description provided for @roleManager.
  ///
  /// In en, this message translates to:
  /// **'Manager'**
  String get roleManager;

  /// No description provided for @roleTechnician.
  ///
  /// In en, this message translates to:
  /// **'Technician'**
  String get roleTechnician;

  /// No description provided for @roleInspector.
  ///
  /// In en, this message translates to:
  /// **'Inspector'**
  String get roleInspector;

  /// No description provided for @addRide.
  ///
  /// In en, this message translates to:
  /// **'Add Ride'**
  String get addRide;

  /// No description provided for @description.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get description;

  /// No description provided for @location.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get location;

  /// No description provided for @notes.
  ///
  /// In en, this message translates to:
  /// **'Notes'**
  String get notes;

  /// No description provided for @selectStatus.
  ///
  /// In en, this message translates to:
  /// **'Select Status'**
  String get selectStatus;

  /// No description provided for @statusOperational.
  ///
  /// In en, this message translates to:
  /// **'Operational'**
  String get statusOperational;

  /// No description provided for @statusUnderMaintenance.
  ///
  /// In en, this message translates to:
  /// **'Under Maintenance'**
  String get statusUnderMaintenance;

  /// No description provided for @statusOutOfService.
  ///
  /// In en, this message translates to:
  /// **'Out of Service'**
  String get statusOutOfService;

  /// No description provided for @statusRetired.
  ///
  /// In en, this message translates to:
  /// **'Retired'**
  String get statusRetired;

  /// No description provided for @retiredRidesSection.
  ///
  /// In en, this message translates to:
  /// **'Retired Rides'**
  String get retiredRidesSection;

  /// No description provided for @rideAddedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Ride added successsfully'**
  String get rideAddedSuccessfully;

  /// No description provided for @rideList.
  ///
  /// In en, this message translates to:
  /// **'Ride List'**
  String get rideList;

  /// No description provided for @error.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get error;

  /// No description provided for @noRides.
  ///
  /// In en, this message translates to:
  /// **'No rides found'**
  String get noRides;

  /// No description provided for @crewList.
  ///
  /// In en, this message translates to:
  /// **'Crew Members List'**
  String get crewList;

  /// No description provided for @noCrew.
  ///
  /// In en, this message translates to:
  /// **'No crew Members found'**
  String get noCrew;

  /// No description provided for @noRecords.
  ///
  /// In en, this message translates to:
  /// **'No data found'**
  String get noRecords;

  /// No description provided for @typeInspection.
  ///
  /// In en, this message translates to:
  /// **'Inspection'**
  String get typeInspection;

  /// No description provided for @typeRepair.
  ///
  /// In en, this message translates to:
  /// **'Repair'**
  String get typeRepair;

  /// No description provided for @typeRoutineMaintenance.
  ///
  /// In en, this message translates to:
  /// **'Routine Maintenance'**
  String get typeRoutineMaintenance;

  /// No description provided for @typePartReplacement.
  ///
  /// In en, this message translates to:
  /// **'Part Replacement'**
  String get typePartReplacement;

  /// No description provided for @typeOther.
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get typeOther;

  /// No description provided for @addMaintenanceRecord.
  ///
  /// In en, this message translates to:
  /// **'Add Maintenance Record'**
  String get addMaintenanceRecord;

  /// No description provided for @selectType.
  ///
  /// In en, this message translates to:
  /// **'Select Type of Maintenance'**
  String get selectType;

  /// No description provided for @save.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get save;

  /// No description provided for @recordAddedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Maintenance recorded successfully'**
  String get recordAddedSuccessfully;

  /// No description provided for @crewMember.
  ///
  /// In en, this message translates to:
  /// **'Crew Member'**
  String get crewMember;

  /// No description provided for @status.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get status;

  /// No description provided for @role.
  ///
  /// In en, this message translates to:
  /// **'Role'**
  String get role;

  /// No description provided for @sortByName.
  ///
  /// In en, this message translates to:
  /// **'Sort by name'**
  String get sortByName;

  /// No description provided for @sortByStatus.
  ///
  /// In en, this message translates to:
  /// **'Sort by status'**
  String get sortByStatus;

  /// No description provided for @updateStatus.
  ///
  /// In en, this message translates to:
  /// **'Update Status'**
  String get updateStatus;

  /// No description provided for @statusUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'updated successfully'**
  String get statusUpdatedSuccessfully;

  /// No description provided for @updateCrewMember.
  ///
  /// In en, this message translates to:
  /// **'Update crew member'**
  String get updateCrewMember;

  /// No description provided for @crewMemberInfoUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Crew member\'s information updated successfully'**
  String get crewMemberInfoUpdatedSuccessfully;

  /// No description provided for @search.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get search;

  /// No description provided for @startDate.
  ///
  /// In en, this message translates to:
  /// **'From'**
  String get startDate;

  /// No description provided for @endDate.
  ///
  /// In en, this message translates to:
  /// **'Until'**
  String get endDate;

  /// No description provided for @filterByDate.
  ///
  /// In en, this message translates to:
  /// **'Filter by date'**
  String get filterByDate;

  /// No description provided for @selectPark.
  ///
  /// In en, this message translates to:
  /// **'Select a Park'**
  String get selectPark;

  /// No description provided for @switchParks.
  ///
  /// In en, this message translates to:
  /// **'Switch Parks'**
  String get switchParks;

  /// No description provided for @myDetails.
  ///
  /// In en, this message translates to:
  /// **'Personal Details'**
  String get myDetails;

  /// No description provided for @noParkAssigned.
  ///
  /// In en, this message translates to:
  /// **'Your account has no park assigned, contact an administrator'**
  String get noParkAssigned;

  /// No description provided for @updateRide.
  ///
  /// In en, this message translates to:
  /// **'Update Ride'**
  String get updateRide;

  /// No description provided for @rideUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Ride updated successfully'**
  String get rideUpdatedSuccessfully;

  /// No description provided for @editRide.
  ///
  /// In en, this message translates to:
  /// **'Edit Ride'**
  String get editRide;

  /// No description provided for @close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// No description provided for @moreInfo.
  ///
  /// In en, this message translates to:
  /// **'More Information'**
  String get moreInfo;

  /// No description provided for @deleteRide.
  ///
  /// In en, this message translates to:
  /// **'Delete Ride'**
  String get deleteRide;

  /// No description provided for @cannotDelete.
  ///
  /// In en, this message translates to:
  /// **'This ride has history and can\'t be deleted, only retired'**
  String get cannotDelete;

  /// No description provided for @deleteRideConfirmation.
  ///
  /// In en, this message translates to:
  /// **'Do you want to delete this ride? Once deleted, this action cannot be undone.'**
  String get deleteRideConfirmation;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @delete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get delete;

  /// No description provided for @deleteCrewMember.
  ///
  /// In en, this message translates to:
  /// **'Delete Crew Member'**
  String get deleteCrewMember;

  /// No description provided for @deleteCrewMemberConfirmation.
  ///
  /// In en, this message translates to:
  /// **'Do you want to delete this crew member? Once deleted, this action cannot be undone.'**
  String get deleteCrewMemberConfirmation;

  /// No description provided for @ok.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get ok;

  /// No description provided for @errorInvalidCredentials.
  ///
  /// In en, this message translates to:
  /// **'Incorrect email or password'**
  String get errorInvalidCredentials;

  /// No description provided for @errorInvalidEmail.
  ///
  /// In en, this message translates to:
  /// **'The email address isn\'t valid'**
  String get errorInvalidEmail;

  /// No description provided for @errorEmailInUse.
  ///
  /// In en, this message translates to:
  /// **'This email is already in use'**
  String get errorEmailInUse;

  /// No description provided for @errorTooManyRequests.
  ///
  /// In en, this message translates to:
  /// **'Too many attempts, try again later'**
  String get errorTooManyRequests;

  /// No description provided for @errorNetwork.
  ///
  /// In en, this message translates to:
  /// **'No connection, check your internet and try again'**
  String get errorNetwork;

  /// No description provided for @errorPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'You don\'t have permission to do this'**
  String get errorPermissionDenied;

  /// No description provided for @errorGeneric.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong, please try again'**
  String get errorGeneric;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'he'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'he':
      return AppLocalizationsHe();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
