// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get welcomeBack => 'Welcome Back!';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get login => 'Log in';

  @override
  String get addCrewMember => 'Add Crew Member';

  @override
  String get name => 'Name';

  @override
  String get selectRole => 'Select Role';

  @override
  String get emailValidationError => 'Please enter a valid email address';

  @override
  String get requiredField => 'This is a required field';

  @override
  String get crewMemberNotFound => 'Crew Member not found';

  @override
  String get welcomeActive => 'Welcome, you are now activated';

  @override
  String get loginSuccessful => 'Login successful!';

  @override
  String get crewMemberAddedSuccessfully => 'Crew Member added successfully!';

  @override
  String get roleAdministrator => 'Administrator';

  @override
  String get roleManager => 'Manager';

  @override
  String get roleTechnician => 'Technician';

  @override
  String get roleInspector => 'Inspector';

  @override
  String get addRide => 'Add Ride';

  @override
  String get description => 'Description';

  @override
  String get location => 'Location';

  @override
  String get notes => 'Notes';

  @override
  String get selectStatus => 'Select Status';

  @override
  String get statusOperational => 'Operational';

  @override
  String get statusUnderMaintenance => 'Under Maintenance';

  @override
  String get statusOutOfService => 'Out of Service';

  @override
  String get statusRetired => 'Retired';

  @override
  String get retiredRidesSection => 'Retired Rides';

  @override
  String get rideAddedSuccessfully => 'Ride added successsfully';

  @override
  String get rideList => 'Ride List';

  @override
  String get error => 'Error';

  @override
  String get noRides => 'No rides found';

  @override
  String get crewList => 'Crew Members List';

  @override
  String get noCrew => 'No crew Members found';

  @override
  String get noRecords => 'No data found';

  @override
  String get typeInspection => 'Inspection';

  @override
  String get typeRepair => 'Repair';

  @override
  String get typeRoutineMaintenance => 'Routine Maintenance';

  @override
  String get typePartReplacement => 'Part Replacement';

  @override
  String get typeOther => 'Other';

  @override
  String get addMaintenanceRecord => 'Add Maintenance Record';

  @override
  String get selectType => 'Select Type of Maintenance';

  @override
  String get save => 'Save';

  @override
  String get recordAddedSuccessfully => 'Maintenance recorded successfully';

  @override
  String get crewMember => 'Crew Member';

  @override
  String get status => 'Status';

  @override
  String get role => 'Role';

  @override
  String get sortByName => 'Sort by name';

  @override
  String get sortByStatus => 'Sort by status';

  @override
  String get updateStatus => 'Update Status';

  @override
  String get statusUpdatedSuccessfully => 'updated successfully';

  @override
  String get updateCrewMember => 'Update crew member';

  @override
  String get crewMemberInfoUpdatedSuccessfully =>
      'Crew member\'s information updated successfully';

  @override
  String get search => 'Search';

  @override
  String get startDate => 'From';

  @override
  String get endDate => 'Until';

  @override
  String get filterByDate => 'Filter by date';

  @override
  String get selectPark => 'Select a Park';

  @override
  String get switchParks => 'Switch Parks';

  @override
  String get myDetails => 'Personal Details';

  @override
  String get noParkAssigned =>
      'Your account has no park assigned, contact an administrator';

  @override
  String get updateRide => 'Update Ride';

  @override
  String get rideUpdatedSuccessfully => 'Ride updated successfully';

  @override
  String get editRide => 'Edit Ride';

  @override
  String get close => 'Close';

  @override
  String get moreInfo => 'More Information';

  @override
  String get deleteRide => 'Delete Ride';

  @override
  String get cannotDelete =>
      'This ride has history and can\'t be deleted, only retired';

  @override
  String get deleteRideConfirmation =>
      'Do you want to delete this ride? Once deleted, this action cannot be undone.';

  @override
  String get cancel => 'Cancel';

  @override
  String get delete => 'Delete';

  @override
  String get deleteCrewMember => 'Delete Crew Member';

  @override
  String get deleteCrewMemberConfirmation =>
      'Do you want to delete this crew member? Once deleted, this action cannot be undone.';

  @override
  String get ok => 'OK';

  @override
  String get errorInvalidCredentials => 'Incorrect email or password';

  @override
  String get errorInvalidEmail => 'The email address isn\'t valid';

  @override
  String get errorEmailInUse => 'This email is already in use';

  @override
  String get errorTooManyRequests => 'Too many attempts, try again later';

  @override
  String get errorNetwork => 'No connection, check your internet and try again';

  @override
  String get errorPermissionDenied => 'You don\'t have permission to do this';

  @override
  String get errorGeneric => 'Something went wrong, please try again';
}
